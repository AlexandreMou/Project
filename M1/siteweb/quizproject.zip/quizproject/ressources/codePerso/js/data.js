// Les donnée 

var offres = {"id":1,
              "titre":"Developpeur web",
              "description":"lzezfejkfzkejfkzefkzjekfezkfzefjzekj",
              "typeContrat": "CDI",
              "dateDebut": "01/03/2021",
              "nbExperience" : "2 ans",
              "fonction" : "XXXX",
              "secteur" : "Technologie",
              "typeEntreprise":"PME",
              "modeTravail" : "Télétravail ponctuel",
              "dateLimite" : "02/02/2021",
              
};